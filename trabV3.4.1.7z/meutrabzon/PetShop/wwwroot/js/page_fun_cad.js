id = 0;
resp = "";
response = "";
var cadastro = {

    init: function () {
        y.onclick("btnSalvar", cadastro.btnSalvarOnClickPt1);
        y.onclick("btnDeletar", cadastro.btnDeletarOnClickPt1);
        y.onclick("btnCancelar", cadastro.btnCancelarOnClick);
        y.onclick("btnPesquisar", cadastro.btnPesquisarOnClick);
    },
    btnSalvarOnClickPt1: function () {
        dialog.confirm("Cadastrar usuario ?", function () { 

           cadastro.btnSalvarOnClickPt2();

        });
        
    },
    btnSalvarOnClickPt2: function () {

        if (!validation.formIsValid()) {
            return;

        }
        var dados = {
            id: id,
            nome: y.byId("nomeCompleto").value,
            cpf: y.byId("cpf").value,
            rg: y.byId("rg").value,
            sexo: y.byId("sexo").value,
            senha: y.byId("senha").value
        }

        y.ajax(dados, "/Funcionario/Cadastrar", "POST",
            function (retServ) {
                if (!retServ.operacao) {
                    y.byId("divMsg").innerHTML = retServ.msg;
                }
                else dialog.alertSuccess("Cadastrado com sucesso.");

            },
            function () {

                dialog.alertError("Alguem erro aconteceu!");

            });

    },
    btnCancelarOnClick: function () {
        window.href.location = window.href.location;

    },
    btnDeletarOnClickPt1: function () {
        
        dialog.Request("Informe o Id.", function (id1) { 
        id = id1;
        cadastro.btnDeletarOnClickPt2();
        })
        
        
        

    },

    btnDeletarOnClickPt2: function () {
        var dados = {
            id: id,
        }
        y.ajax(dados, "/Funcionario/Deletar", "POST", function (retServ) {
            if (!retServ.operacao) {
                y.byId("divMsg").innerHTML = retServ.msg;
            }
            else dialog.alertSuccess("Funcionario deletado com sucesso!");
        },
            function () { dialog.alertError("Algum erro aconteceu!"); })
    },


    btnPesquisarOnClick: function () {

        $.fancybox.open({
            src: "/Funcionario/Pesquisar",
            type: 'iframe',
            iframe: {
                css: {
                    'min-width': '400px',
                    'max-width': '600px',
                    'height': '500px'
                }
            }

        });
    },

    editar: function (id) {

        $.fancybox.close();

        var dados = {
            id: id
        }

        y.ajax(dados, "/Funcionario/ObterPorId", "POST", function (retServ) {

            y.byId("senha").disabled = "disabled";
            cadastro.id = retServ.id;
            y.byId("nome").value = retServ.nomeCompleto;
            y.byId("nomeUsuario").value = retServ.nomeUsuario;

        }, function () {
            alert("Não foi possível obter o funcionário");
        });

    },


    btnCancelarOnClick: function () {

        window.location.href = window.location.href;

    },

}

document.addEventListener("DOMContentLoaded", function () {

    cadastro.init();

});


