
    //<script>
    //var cadastro = {
    //    init : function(){
    //        y.onclick("BtnCadastrar",cadastro.BtnCadastrarOnClick)
    //    },
    //    BtnCadastrarOnClick : function (){
    //        if(y.byId("nomePet").value=="" ||y.byId("horaData").value == "")
    //        {
    //            y.byId("msg").innerHTML ="Preencha todos os campos"
    //            return;
    //        }
    //        var dados = {
    //            nomeCli : y.byId("nomeCli").value,
    //            nomePet : y.byId("nomePet").value
    //        }
    //        y.ajax(dados,"/Banho/Cadastrar","POST",function(){//sucesso
    //        },function(){//falha
    //        });

    //    }  
    //}
    //document.addEventListner("DOMContentLoaded",function(){cadastro.init();});



    //</script>