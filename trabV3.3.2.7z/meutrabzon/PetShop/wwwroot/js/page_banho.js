
    var pesquisar = {

        init: function () { 

            y.onclick("btnPesquisar", pesquisar.btnPesquisarOnClick);
        },
        
        onkeyup: function (id, f) {
            simplaojs.byId(id).onkeyup = f;
        },
         on: function (event, elementos, f) {

        for (var i = 0; i < elementos.length; i++) {

            if (event == "click") {

                elementos[i].onclick = f;
            }
            else if (event == "blur") {
                elementos[i].onblur = f;

            }
            else if (event == "change") {
                elementos[i].onchange = f;

            }
        }

    },
        btnPesquisarOnClick: function () {
            var dados = {
                nome: ""
                }

            y.ajax(dados, "/Banho/EnvPesquisar", "POST", function (banhos) { 

                pesquisar.gerarGrid(banhos);

            }, function () { 

                dialog.alertError('Não foi possível obter os Banhos.');

            } )

        },      
        observerBanho: function (dados) {
            
            y.ajax(dados, "/Banho/ObserverBanho", "POST", function (banhos) {
                var infos = "";
                var banhosRealizados = y.byId("banhosRealizados");
                var template = "<ul>" +
                    " <li>{nomeCli}</li>" +
                    " <li>{nomeAni}</li>" +
                    " <li>{emailCli}</li> <ul>";
                for (var i = 0; i < banhos.length; i++) {
                    infos += y.renderTemplate(template, banhos[i]);
                    
                }
                banhosRealizados.innerHTML = infos;

            }, function () { })
        },
        gerarGrid: function (funcionarios) { 

            var tbodyResultado = y.byId("tbodyResultado");
      
            var template = "<tr style='padding-left:50px'>" +
                           "  <td scope=\"row\">{codigobanho}</td>"+
                           "  <td>{valor}</td>"+
                           "  <td>{nomeFunc}</td>"+
                           "  <td>{nomeAni}</td>"+
                           "  <td>{nomeCli}</td>" + 
                           "  <td><input data-id=\"{codigobanho}\" class=\"btn btn-custom\" type=\"button\" value=\"Realizar\" /></td>" + 
                           "</tr > ";

            var linhas = "";
            for (var i = 0; i < funcionarios.length; i++) {
                linhas += y.renderTemplate(template, funcionarios[i]);
            }

            tbodyResultado.innerHTML = linhas;

            if (linhas == 0) {

                y.byId("divDados").style.display = "none"
            }
            else y.byId("divDados").style.display = "block";
    
            var aEditar = y.bySelectorAll("table input[data-id]");


            pesquisar.on("click", aEditar, pesquisar.selecionarOnClick);
         
        },

        selecionarOnClick: function () { 
            var id = this.getAttribute("data-id");
            if(id!=0){
            dialog.confirm("Deseja alterar status para realizado ? ", function () { 
                   var id2 = id;
                   pesquisar.btnSalvarOnClick2(id);

                });}
        },
        btnSalvarOnClick2: function (id) {
                var dados = {
                  
                    id: id,
                }
                y.ajax(dados, "/Banho/RealizarBanho", "POST",
                    function (retServ) {
                        if (!retServ.operacao) {
                            y.byId("divMsg").innerHTML = retServ.msg;
                        }
                        else window.location.href = window.location.href; 

                    },
                    function () {

                        dialog.alertError("Algum erro ocorreu.");

                    });
        },

    }

    document.addEventListener("DOMContentLoaded", function () {
        pesquisar.init();
        pesquisar.btnPesquisarOnClick();
        pesquisar.observerBanho();
    });

