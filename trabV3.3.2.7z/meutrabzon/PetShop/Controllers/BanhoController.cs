﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace PetShop.Controllers
{
    public class BanhoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Registar()
        {
            return View();
        }

        //public JsonResult Cadastrar([FromBody]Dictionary<string,string>dados)
        //{
        //    string msg=""; bool operacao = false;
        //    Models.Banho b = new Models.Banho();
        //    b.NomeCliente = dados["nomeCliente"]; b.NomePet = dados["nomePet"];b.TamanhoPet = dados["tamanhoPet"];
        //    b.TipoServico = dados["tipoServico"];b.HorarioData = dados["horarioData"]; b.HorarioHora = dados["horarioHora"];

        //    operacao = b.Gravar(out msg);
        //    var retorno = new
        //    {
        //        msg = msg,
        //        operacao = operacao
        //    };
        //    return Json(retorno);
        //}
        public IActionResult TelaLogar()
        {
            return Redirect("/Funcionario/Index");
        }
        public IActionResult RealizaBanho()
        {
            return View("Index");
        }
        [HttpPost]
        public JsonResult EnvPesquisar([FromBody] Dictionary<string, string> dados)
        {
            Models.Banho b = new Models.Banho();
            List<object> retorno = new List<object>();
                List<Models.Banho> bs = b.ObterPorData();

                foreach (Models.Banho bItem in bs)
                {
                    var obj = new
                    {
                        codigobanho = bItem.CodigoBanho,
                        data= bItem.DataAtual,
                        valor = bItem.Valor,
                        nomeFunc = bItem.NomeFunc,
                        nomeCli = bItem.NomeCli,
                        nomeAni = bItem.NomeAni
                    };

                    retorno.Add(obj);
                }

            return Json(retorno);
        }
        public JsonResult RealizarBanho([FromBody] Dictionary<string,string> dados)
        {
            string msg = "";int id;
            bool operacao = false;
            Models.Banho b = new Models.Banho();
          
                id = (Convert.ToInt32(dados["id"]));
                operacao = b.RealizarBanho(out msg, id);


            var retorno = new
            {
                operacao = operacao,
                msg = msg
            };


            return Json(retorno);
        }
        public JsonResult ObserverBanho([FromBody]Dictionary<string,string> dados)
        {
            Models.Banho b = new Models.Banho();
            List<object> retorno = new List<object>();
            List<Models.Banho> bo = b.ObserverBanho();

            foreach (Models.Banho bItem in bo)
            {
                var obj = new
                {
                    dataAtual = bItem.DataAtual,
                    horario = bItem.Horario,
                    nomeAni = bItem.NomeAni,
                    nomeCli = bItem.NomeCli,
                    emailCli = bItem.EmailCli
                };

                retorno.Add(obj);
            }
            
            return Json(retorno);
        }
    }
}
 