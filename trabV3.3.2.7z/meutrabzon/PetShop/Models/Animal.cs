using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class Animal
    {
        private int _idani;
        private string _nome;
        private string _corPelo;
        private string _raca;
        private string _tamanho;
        private int _idcli;
        public int _PegaId;
        public string _PegaNome;
        public string GetNomeCompleto()
        {         
            _PegaNome = _nome;   
            return _nome;
        }
        public void SetNomeCompleto(string _nome)
        {
            this._nome = _nome;
            _PegaNome = _nome;   
        }
        public string GetCorPelo() { return _corPelo; }
        public void SetCorPelo(string _corPelo) { this._corPelo = _corPelo; }
        public string GetRaca() { return _raca; }
        public void SetRaca(string _raca) { this._raca = _raca; }
        public string GetTamanho() { return _tamanho; }
        public void SetTamanho(string _tamanho) { this._tamanho = _tamanho; }
        public int GetId() { _PegaId = _idani;return _idani; }
        public void SetId(int _idani) { this._idani = _idani;_PegaId = _idani; }
        public int GetIdcli() { return _idcli; }
        public void SetIdcli(int _idcli) { this._idcli = _idcli; }


        public Animal()
        {


        }
        public Animal(int id)
        {
            if(ObterPorId(id))
            {
                
            }
        }
        public Animal(string nomeCompleto, string corPelo, string raca, string tamanho, int idcli)
        {
            SetNomeCompleto(nomeCompleto);
            SetCorPelo(corPelo);
            SetRaca(raca);
            SetTamanho(tamanho);
            SetIdcli(idcli);
        }




        public bool Autenticar(string corPelo, string idcli)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string select = @"select count(*) 
                              from Animal 
                              where corPelo = @corPelo and
                                    idcli = @idcli";

            Dictionary<string, string> ps = new Dictionary<string, string>();
            ps.Add("@corPelo", corPelo);
            ps.Add("@idcli", idcli.ToString());

            string msg = "";
            object count = bd.ExecutarScalar(select, ps, out msg);

            if (Convert.ToInt32(count) == 0)
                return false;
            else return true;
        }

        public bool Gravar(out string msg)
        {
            msg = "";       

            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "";
            Dictionary<string, string> ps = new Dictionary<string, string>();
            if (_idani == 0)
            {
                sql = @"insert into Animal (nome, corPelo, raca, tamanho, idcli)
                         values (@nomecompleto, @corPelo, @raca, @tamanho, @idcli)";
                
            }
            else {

                sql = @"update Animal set 
                                    nome = @nomecompleto, 
                                    raca = @raca,
                                    tamanho = @tamanho,
                                    corPelo = @corPelo
                                  where idani = @id";

                ps.Add("@id", _idani.ToString());
            }

            ps.Add("@nomecompleto", _nome);
            ps.Add("@corPelo", _corPelo);
            ps.Add("@raca", _raca);
            ps.Add("@tamanho", _tamanho);
            ps.Add("@idcli", _idcli.ToString());

            int linhas = bd.ExecutarNonQuery(sql, ps, out msg);

            if (_idani == 0)
            {
                SetId(bd.UltimoIdInserido);
            }

            return linhas > 0;
        }
        public bool Deletar(int id,out string msg)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string sql = "";
            Dictionary<string, string> bs = new Dictionary<string, string>();
            sql = @"delete from  Animal where idani = @idani";
            bs.Add("@idani", id.ToString());
            int linhas = bd.ExecutarNonQuery(sql, bs, out msg);
            if (linhas > 0)
            {
                return true;
            }
            return false;
        }

        public bool ObterPorId(int id) {

            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "select * from Animal where idani = " + id;
            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, out msg);

            if (dt.Rows.Count == 1)
            {
                SetId(Convert.ToInt32(dt.Rows[0]["idani"]));
                SetNomeCompleto(dt.Rows[0]["nome"].ToString());
                SetCorPelo(dt.Rows[0]["corPelo"].ToString());
                SetRaca(dt.Rows[0]["raca"].ToString());
                SetTamanho(dt.Rows[0]["tamanho"].ToString());
                SetIdcli(Convert.ToInt32(dt.Rows[0]["idcli"]));
                return true;
            }
            else return false;

        }

        public List<Animal> Pesquisar(string nome)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "select * from Animal where nome like @nome";
            Dictionary<string, string> parametros = new Dictionary<string, string>();
            parametros.Add("@nome", nome + "%");

            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, parametros, out msg);
            List<Animal> bs = new List<Animal>();
            foreach (DataRow row in dt.Rows)
            {
                Animal b = new Animal();
                b.SetId(Convert.ToInt32(row["idani"])); 
                b.SetNomeCompleto(row["nome"].ToString());
                b.SetCorPelo(row["corPelo"].ToString());
                b.SetRaca(row["raca"].ToString());
                b.SetTamanho(row["tamanho"].ToString());
                b.SetIdcli(Convert.ToInt32(row["idcli"].ToString()));
                bs.Add(b);

            }
            return bs;

        }

    }
}
