
    var pesquisar = {

        init: function () { 

            pesquisar.onkeyup("txtPesquisar", pesquisar.txtPesquisarOnKeyUp);
            y.onclick("btnPesquisar", pesquisar.btnPesquisarOnClick);

        },
        
        onkeyup: function (id, f) {
            simplaojs.byId(id).onkeyup = f;
        },
         on: function (event, elementos, f) {

        for (var i = 0; i < elementos.length; i++) {

            if (event == "click") {

                elementos[i].onclick = f;
            }
            else if (event == "blur") {
                elementos[i].onblur = f;

            }
            else if (event == "change") {
                elementos[i].onchange = f;

            }
        }

    },

        btnPesquisarOnClick: function () {


            var dados = {
                nome: y.byId("txtPesquisar").value
            };

            y.ajax(dados, "/Funcionario/EnvPesquisar", "POST", function (funcionarios) { 

                pesquisar.gerarGrid(funcionarios);

            }, function () { 

                dialog.alertError('Não foi possível obter os funcionários.');

            } )

        },

        txtPesquisarOnKeyUp: function () {

            var dados = {
                nome: y.byId("txtPesquisar").value
            };

            y.ajax(dados, "/Funcionario/EnvPesquisar", "POST", function (funcionarios) {

                pesquisar.gerarGrid(funcionarios);

            }, function () {

                dialog.alertError('Não foi possível obter os funcionários.');

            })

        },

        gerarGrid: function (funcionarios) { 

            var tbodyResultado = y.byId("tbodyResultado");

            var template = "<tr style='padding-left:50px'>" +
                           "   <td scope=\"row\">{id}</td>"+
                           "   <td>{nome}</td>"+
                           "   <td>{cpf}</td>" + 
                           "   <td><input type=button class='btn btn-custom' id='{id}' data-id=\"{id}\" value=editar /></td>" + 
                           "</tr > ";


            var linhas = "";
            for (var i = 0; i < funcionarios.length; i++) {
                linhas += y.renderTemplate(template, funcionarios[i]);
            }

            tbodyResultado.innerHTML = linhas;

            if (linhas == 0) {

                y.byId("divDados").style.display = "none"
            }
            else y.byId("divDados").style.display = "block";

            var aEditar = y.bySelectorAll("table a[data-id]");


            y.on("click", aEditar, pesquisar.selecionarOnClick);
         
        },

        selecionarOnClick: function () { 
            var id = this.getAttribute("data-id");
            window.parent.cadastro.editar(id);
        }

    }

    document.addEventListener("DOMContentLoaded", function () {
        pesquisar.init();
    });

