using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class Cliente
    {
        private int _id;
        private string _nome;
        private string _cpf;
        private string _sexo;
        public int _PegaId;
        public string _PegaNome;
        public string GetNome()
        {         
            _PegaNome = _nome;   
            return _nome;
        }
        public void SetNome(string _nome)
        {
            this._nome = _nome;
            _PegaNome = _nome;   
        }
        public string GetCpf() { return _cpf; }
        public void SetCpf(string _cpf) { this._cpf = _cpf; }

        public string GetSexo() { return _sexo; }
        public void SetSexo(string _sexo) { this._sexo = _sexo; }
        public int GetId() { return _id; }
        public void SetId(int _id) { this._id = _id;_PegaId = _id; }
        
        


        public Cliente()
        {


        }
        public Cliente(int id)
        {
            if(ObterPorId(id))
            {
                
            }
        }
        public Cliente(string nome, string cpf, string sexo)
        {
            SetNome(nome);
            SetCpf(cpf);
            SetSexo(sexo);            
        }




        public bool Autenticar(string cpf)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string select = @"select count(*) 
                              from Cliente 
                              where cpf = @cpf";

            Dictionary<string, string> ps = new Dictionary<string, string>();
            ps.Add("@cpf", cpf);            

            string msg = "";
            object count = bd.ExecutarScalar(select, ps, out msg);

            if (Convert.ToInt32(count) == 0)
                return false;
            else return true;
        }

        public bool Gravar(out string msg)
        {
            msg = "";


            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "";
            Dictionary<string, string> ps = new Dictionary<string, string>();
            if (_id == 0)
            {
                sql = @"insert into Cliente (nome, cpf, sexo)
                         values (@nome, @cpf, @sexo";
                
            }
            else {

                sql = @"update Cliente set 
                                    nome = @nome, 
                                    sexo = @sexo,
                                    cpf = @cpf
                                  where idcli = @id";

                ps.Add("@id", _id.ToString());
            }

            ps.Add("@nome", _nome);
            ps.Add("@cpf", _cpf);
            ps.Add("@sexo", _sexo);

            int linhas = bd.ExecutarNonQuery(sql, ps, out msg);

            if (_id == 0)
            {
                SetId(bd.UltimoIdInserido);
            }

            return linhas > 0;
        }
        public bool Deletar(int id,out string msg)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string sql = "";
            Dictionary<string, string> cs = new Dictionary<string, string>();
            sql = @"delete from  Cliente where idcli = @idcli";
            cs.Add("@idcli", id.ToString());
            int linhas = bd.ExecutarNonQuery(sql, cs, out msg);
            if (linhas > 0)
            {
                return true;
            }
            return false;
        }

        public bool ObterPorId(int id) {

            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "select * from Cliente where idcli = " + id;
            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, out msg);

            if (dt.Rows.Count == 1)
            {
                SetId(Convert.ToInt32(dt.Rows[0]["idcli"]));
                SetNome(dt.Rows[0]["nome"].ToString());
                SetCpf(dt.Rows[0]["cpf"].ToString());
                SetSexo(dt.Rows[0]["sexo"].ToString());      
                return true;
            }
            else return false;

        }

        public List<Cliente> Pesquisar(string nome)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

            string sql = "select * from Cliente where nome like @nome";
            Dictionary<string, string> parametros = new Dictionary<string, string>();
            parametros.Add("@nome", nome + "%");

            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, parametros, out msg);
            string aux ="";
            List<Cliente> cs = new List<Cliente>();
            foreach (DataRow row in dt.Rows)
            {
                Cliente c = new Cliente();
                c.SetId(Convert.ToInt32(row["idcli"]));
                aux = row["nome"].ToString();        
                c.SetNome(row["nome"].ToString());
                c.SetCpf(row["cpf"].ToString());
                c.SetSexo(row["sexo"].ToString());

                cs.Add(c);

            }
            return cs;

        }
        public string ObterPorNome(string nome)
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string sql = "select * from cliente where nome like '"+nome+""+"'";
            Dictionary<string, string> parametros = new Dictionary<string, string>();
            parametros.Add("@nome", nome + "%");
            string ret="";
            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, parametros, out msg);
            List<Cliente> cs = new List<Cliente>();
            foreach (DataRow row in dt.Rows)
            {
                Cliente c = new Cliente();
                c.SetId(Convert.ToInt32(row["idcli"]));
                c.SetNome(row["nome"].ToString());
                c.SetCpf(row["cpf"].ToString());
                c.SetSexo(row["sexo"].ToString());
                ret = c.GetId().ToString() ;
                cs.Add(c);

            }
            return ret ;

        }
    }
}
