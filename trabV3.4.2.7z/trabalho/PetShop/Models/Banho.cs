using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class Banho
    {
        private int _id;
        private int _codigoBanho;
        private string _dataAtual;
        private string _valor;
        private string _idAni;
        private string _idCli;
        private string _idFun;
        private string _nomeFunc;
        private string _nomeAni;
        private string _nomeCli;
        private string _emailCli;
        private string _Horario;

    public int Id { get => _id; set => _id = value; }
    public string NomeFunc{ get => _nomeFunc; set=>_nomeFunc = value;}
    public string NomeAni{ get => _nomeAni; set=>_nomeAni = value;}
    public string NomeCli{ get => _nomeCli; set=>_nomeCli = value;}
    public int CodigoBanho { get => _codigoBanho; set => _codigoBanho = value; }
    public string Valor{get => _valor; set => _valor = value;}
    public string IdAni{get => _idAni; set => _idAni = value;}
    public string IdCli{get => _idCli; set => _idCli = value;}
    public string IdFun { get => _idFun; set => _idFun = value; }
    public string DataAtual{get => _dataAtual; set => _dataAtual = value;}
    public string EmailCli { get => _emailCli; set => _emailCli = value; }
    public string Horario { get => _Horario; set => _Horario = value; }
    public Banho() {}
    public Banho(int codigoBanho, string valor, string idani,
     string idcli,string idfun, string dataAtual){
         CodigoBanho = codigoBanho;
         Valor = valor;
         IdAni = idani;
         IdCli = idcli;
         IdFun = idfun;
         DataAtual = dataAtual;
    }
    public bool ObtemCliente()
        {
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            Dictionary<string, string> ps = new Dictionary<string, string>();
            string sql = @"select f.nome as fnome from banho " +                          
                            "where banho.idcli = '@idcli'";
            ps.Add("@idcli", _idCli);
            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, out msg);

            List<Banho> bs = new List<Banho>();
            foreach (DataRow row in dt.Rows)
            {
                Banho b = new Banho();
                b.CodigoBanho = Convert.ToInt32(row["codigoBanho"].ToString());
                b.DataAtual = row["dataAtual"].ToString();
                b.Valor = row["valor"].ToString();
                b.NomeAni = row["anome"].ToString();
                b.NomeCli = row["cnome"].ToString();
                b.NomeFunc = row["fnome"].ToString();
                bs.Add(b);
            }

            return true ;
        }
    //public bool RegistraBanho()
    //    {

    //        DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

    //        string sql = "";
    //        Dictionary<string, string> ps = new Dictionary<string, string>();
    //        if (_id == 0)
    //        {
    //            sql = @"insert into funcionario (nome, cpf, rg, sexo, senha)
    //                     values (@nomecompleto, @cpf, @rg, @sexo, @senha)";

    //        }
    //        else
    //        {

    //            sql = @"update funcionario set 
    //                                nome = @nomecompleto, 
    //                                rg = @rg,
    //                                sexo = @sexo,
    //                                cpf = @cpf
    //                              where idfunc = @id";

    //            ps.Add("@id", _id.ToString());
    //        }

    //        ps.Add("@nomecompleto", _nomeCompleto);
    //        ps.Add("@cpf", _cpf);
    //        ps.Add("@rg", _rg);
    //        ps.Add("@sexo", _sexo);
    //        ps.Add("@senha", _senha.ToString());

    //        int linhas = bd.ExecutarNonQuery(sql, ps, out msg);

    //        if (_id == 0)
    //        {
    //            SetId(bd.UltimoIdInserido);
    //        }

    //        return linhas > 0;
    //    }
    public List<Banho> ObterPorData() {
        //antigo sql ="select * from banho where dataAtual = '" + ordenaData()+"' and realizado = 'N'";
        DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
        string sql = "select codigoBanho, dataAtual,valor,c.nome as cnome, a.nome as anome, f.nome as fnome, realizado from banho "+
                        "INNER JOIN cliente c ON banho.idcli = c.idcli "+
                        "INNER JOIN animal a ON banho.idani = a.idani "+
                        "INNER JOIN funcionario f ON banho.idfunc = f.idfunc "+
                        "where banho.dataAtual = '"+ ordenaData()+"' and realizado = 'N'";
        string msg = "";
        DataTable dt = bd.ExecutarSelect(sql, out msg);

        List<Banho> bs = new List<Banho>();
        foreach (DataRow row in dt.Rows)
        {
            Banho b = new Banho();
            b.CodigoBanho = Convert.ToInt32(row["codigoBanho"].ToString());
            b.DataAtual = row["dataAtual"].ToString();
            b.Valor = row["valor"].ToString();
            b.NomeAni = row["anome"].ToString();
            b.NomeCli = row["cnome"].ToString();
            b.NomeFunc = row["fnome"].ToString();
            bs.Add(b);
        }
            
        return bs;

    }
        public List<Banho> PesquisarPorID(int id)
        {
            //antigo sql ="select * from banho where dataAtual = '" + ordenaData()+"' and realizado = 'N'";
            DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
            string sql = "select horario, banho.idani, codigoBanho, dataAtual,valor,c.nome as cnome, a.nome as anome, f.nome as fnome, realizado from banho " +
                            "INNER JOIN cliente c ON banho.idcli = c.idcli " +
                            "INNER JOIN animal a ON banho.idani = a.idani " +
                            "INNER JOIN funcionario f ON banho.idfunc = f.idfunc " +
                            "where banho.idani = " + id;
            string msg = "";
            DataTable dt = bd.ExecutarSelect(sql, out msg);
            string aux = ""; string[] aux2;
            List<Banho> bs = new List<Banho>();
            string auxHorario = "";
            foreach (DataRow row in dt.Rows)
            {
                Banho b = new Banho();
                b.CodigoBanho = Convert.ToInt32(row["codigoBanho"].ToString());
                aux = row["dataAtual"].ToString();
                aux2 = aux.Split(" ");
                b.DataAtual = aux2[0];
                aux = row["horario"].ToString();
                auxHorario = ordenaHorario(aux);
                b.Horario = auxHorario;
                b.Valor = row["valor"].ToString();
                b.IdAni = row["idani"].ToString();
                b.NomeAni = row["anome"].ToString();
                b.NomeCli = row["cnome"].ToString();
                b.NomeFunc = row["fnome"].ToString();
                bs.Add(b);
            }

            return bs;

        }
        public string ordenaHorario(string aux)
        {
            string aux2 = aux;
            int auX;
            if(int.TryParse(aux, out auX))
            {
                if (auX <= 9)
                {
                    aux2 = "�s 0" + auX.ToString() + ":00 Hrs";
                }
                else if (auX > 9)
                {
                    aux2 = "�s " + auX.ToString() + ":00 Hrs";
                }
            }

            return aux2;
        }
        public bool RealizarBanho(out string msg, int id)
    {
        DAL.MySqlPersistence bd = new DAL.MySqlPersistence();

        string sql = "";
        Dictionary<string, string> ps = new Dictionary<string, string>();
            sql = @"update banho set realizado = 'S' where codigoBanho = @id";

        ps.Add("@id", id.ToString());

        int linhas = bd.ExecutarNonQuery(sql, ps, out msg);

        return linhas > 0;
    }
    public List<Banho> ObserverBanho()
    {
        DAL.MySqlPersistence bd = new DAL.MySqlPersistence();
        string sql = "select codigoBanho, dataAtual, valor, c.email as cemail, a.nome as anome, " +
                     " c.nome as cnome, b.horario as hora, realizado from banho b " +
                     "INNER JOIN cliente c ON b.idcli = c.idcli " +
                     "INNER JOIN animal a ON b.idani = a.idani " +
                     "INNER JOIN funcionario f ON b.idfunc = f.idfunc " +
                     "where b.dataAtual = '" + ordenaData() + "' and realizado = 'S'"; ;
        string msg = "";
        DataTable dt = bd.ExecutarSelect(sql, out msg);

        List<Banho> bs = new List<Banho>();
        foreach (DataRow row in dt.Rows)
        {
            Banho b = new Banho();
            b.DataAtual = row["dataAtual"].ToString();
            b.Horario = row["hora"].ToString();
            b.NomeAni = row["anome"].ToString();
            b.NomeCli = row["cnome"].ToString();
            b.EmailCli = row["cemail"].ToString();
            bs.Add(b);
        }

        return bs;
        }
    public string ordenaData()
        {
            DateTime data = DateTime.Today;
            string datE = data.ToString();
            datE = datE.Replace("/", "-");
            string[] datEs = datE.Substring(0).Split(" ");
            string[] datEs2 = datEs[0].Substring(0).Split("-");
            string dataF = datEs2[2] + "-" + datEs2[1] + "-" + datEs2[0];
            return dataF;
        }
    public int horarioAtual()
        {
            int hora;
            DateTime data = DateTime.Now;
            hora = data.Hour;
            return hora;
        }
        public void retornaData(DateTime data)
        {
            Console.WriteLine("{0:dddd}", data);
        }

    }

}